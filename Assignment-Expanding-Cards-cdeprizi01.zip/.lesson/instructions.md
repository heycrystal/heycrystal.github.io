# Expanding Cards  

## Instructions

We are going to build some expanding cards. Basically, we're going to style these panels to have a background image and a heading, we're going to use the CSS **Flexbox** layout option to align everything, and then add a little bit of **JavaScript** to dynamically change how a CSS rule is applied. When a panel is clicked (or tapped using a touch screen), the script will make the panel visible and hide the other panels.  

The images are from [Unsplash](https://unsplash.com/), which is a source of freely usable images. I recommend that you create an Unsplash account to use for your future projects.  

First, familiarize yourself with the structure of the HTML and class names of each div element. Note the nesting of the panel div's within the container div and the placement of the h3 elements. Finally, note the inclusion of the **script.js** file before the closing **body** tag. 


### Style the container class

Add the following CSS rule for the container class after the body rule in **style.css**. This rule sets the container layout to be **Flexbox** with a width of 90% of the viewport width.

```
.container {
  display: flex;
  width: 90vw;
}
```

### Style each panel

Add the following panel class CSS rule after the container rule in **style.css**. This rule also adds a transition animation for the panel. 

```
.panel {
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  height: 80vh;
  border-radius: 50px; /* rounded corners */
  color: #fff; /* white text color */
  cursor: pointer;
  flex: 0.5; /* initial size */
  margin: 10px;
  position: relative;
  transition: all 700ms ease-in;
}
```

### Style the panel h3 element

Style the panel heading text and position. We set the opacity to 0 to hide the h3 text by default. Next, the panel active rule will change the opacity value. 

```
.panel h3 {
  font-size: 24px;
  position: absolute;
  bottom: 20px;
  left: 20px;
  margin: 0;
  opacity: 0; /* hide by default */
}
```

### Style the panel active state

Now let's change the active panel size and make visible. Adds a transition animation for the heading. 

```
.panel.active {
  flex: 5; /* increase the size */
}

.panel.active h3 {
  opacity: 1; /* show this h3 */
  transition: opacity 0.3s ease-in 0.4s;
}
```

### Reduce visible panels on small screens

Use a **media query** to detect smaller screen sizes and reduce the number of visible panels. The 4th and 5th panels will be hidden by setting the **display** property to **none**. 

```
@media (max-width: 480px) {
  .container {
    width: 100vw;
  }

  .panel:nth-of-type(4),
  .panel:nth-of-type(5) {
    display: none;
  }
}
```

### JavaScript

Add the following JavaScript code to the **script.js** file. The script will set the clicked panel to active by adding the CSS active class to the selected panel and removing the CSS active class from the other panels.  

```
const panels = document.querySelectorAll('.panel')

panels.forEach(panel => {
    panel.addEventListener('click', () => {
        removeActiveClasses()
        panel.classList.add('active')
    })
})

function removeActiveClasses() {
    panels.forEach(panel => {
        panel.classList.remove('active')
    })
}
```

### Test, test, test

Now test the page using different screen widths and heights. Observe any behavior and formatting differences. 

Comment out the CSS transition animations and note the differences with and without these animations. 
